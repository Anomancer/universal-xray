(() => {
  'use strict';
  if (globalThis.__BHC_XRAY_INTERCEPT_150__) return;
  globalThis.__BHC_XRAY_INTERCEPT_150__ = true;

  const state = { result:null, lens:'general', markers:[], domBadges:[], markerRefs:[], domBadgeRefs:[], visible:true, panel:null, candidates:[], friction:null };
  const cleanText = s => String(s || '').replace(/\s+/g,' ').trim();
  const visible = el => {
    if (!(el instanceof Element)) return false;
    const cs=getComputedStyle(el); if(cs.display==='none'||cs.visibility==='hidden'||Number(cs.opacity)===0) return false;
    const r=el.getBoundingClientRect(); return r.width>3&&r.height>3&&r.bottom>=0&&r.right>=0&&r.top<=innerHeight&&r.left<=innerWidth;
  };
  const safeText = el => cleanText(el.innerText || el.textContent || '');
  function collectPageText() {
    const root=document.body; if(!root) return '';
    const clone=root.cloneNode(true);
    clone.querySelectorAll('script,style,noscript,template,svg,canvas,#bhc-xray-intercept-root,.bhc-xray-marker,.bhc-xray-dom-badge').forEach(n=>n.remove());
    return cleanText(clone.innerText || clone.textContent || '').slice(0,160000);
  }
  function collectCandidates() {
    const selector='h1,h2,h3,h4,p,li,button,a,label,[role="button"],[aria-label]';
    const seen=new Set(), out=[];
    document.querySelectorAll(selector).forEach(el=>{
      if(!visible(el)||el.closest('#bhc-xray-intercept-root')) return;
      const text=safeText(el); if(text.length<3||text.length>420) return;
      const key=text.slice(0,180); if(seen.has(key)) return; seen.add(key);
      out.push({el,text});
    });
    state.candidates=out.slice(0,180);
    return state.candidates;
  }
  function removeMarkers() { [...state.markers,...state.domBadges].forEach(x=>x.remove()); state.markers=[]; state.domBadges=[]; state.markerRefs=[]; state.domBadgeRefs=[]; }
  function addMarker(el, hit) {
    const r=el.getBoundingClientRect();
    const m=document.createElement('div'); m.className='bhc-xray-marker'; m.dataset.group=hit.group || 'frame'; m.dataset.bhcxrayOverlayMarker='1';
    Object.assign(m.style,{left:`${r.left+scrollX}px`,top:`${r.top+scrollY}px`,width:`${r.width}px`,height:`${r.height}px`,display:state.visible?'block':'none'});
    const label=document.createElement('span'); label.className='bhc-xray-marker-label'; label.textContent=`${hit.name} · HEURISTIC`; m.append(label); document.documentElement.append(m); state.markers.push(m); state.markerRefs.push({node:m,el});
  }
  function addDomBadge(el,label) {
    const r=el.getBoundingClientRect(); const b=document.createElement('div'); b.className='bhc-xray-dom-badge'; b.dataset.bhcxrayOverlayMarker='1'; b.textContent=label;
    Object.assign(b.style,{left:`${Math.max(4,r.right+scrollX-150)}px`,top:`${r.top+scrollY+4}px`,display:state.visible?'block':'none'}); document.documentElement.append(b); state.domBadges.push(b); state.domBadgeRefs.push({node:b,el});
  }
  function markDomSignals() {
    document.querySelectorAll('input[type="checkbox"]:checked,input[type="radio"]:checked,select option:checked').forEach(el=>{
      const target=el.tagName==='OPTION'?el.closest('select'):el; if(target&&visible(target)) addDomBadge(target,'PRESELECTED · MEASURED');
    });
    document.querySelectorAll('button,a,[role="button"]').forEach(el=>{
      if(!visible(el)) return; const t=safeText(el); if(/\b(osta|tilaa|varaa|liity|buy|subscribe|checkout|book now)\b/i.test(t)) addDomBadge(el,'CTA · MEASURED');
    });
    document.querySelectorAll('[class*="countdown" i],[id*="countdown" i],[class*="timer" i],[id*="timer" i]').forEach(el=>{if(visible(el)) addDomBadge(el,'TIMER-LIKE DOM · MEASURED');});
  }
  function renderMarkers() {
    removeMarkers(); const lib=globalThis.BHCPatternLibrary; if(!lib) return;
    collectCandidates().forEach(({el,text})=>{ const hits=lib.scanText(text,state.lens); if(hits[0]) addMarker(el,hits[0]); });
    markDomSignals();
  }
  function reposition() {
    if(!state.result) return;
    state.markerRefs.forEach(({node,el})=>{ if(!el.isConnected||!visible(el)){node.style.display='none';return;} const r=el.getBoundingClientRect(); Object.assign(node.style,{left:`${r.left+scrollX}px`,top:`${r.top+scrollY}px`,width:`${r.width}px`,height:`${r.height}px`,display:state.visible?'block':'none'}); });
    state.domBadgeRefs.forEach(({node,el})=>{ if(!el?.isConnected||!visible(el)){node.style.display='none';return;} const r=el.getBoundingClientRect(); Object.assign(node.style,{left:`${Math.max(4,r.right+scrollX-150)}px`,top:`${r.top+scrollY+4}px`,display:state.visible?'block':'none'}); });
  }
  let raf=0; const schedule=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(reposition)};
  addEventListener('resize',schedule,{passive:true}); addEventListener('scroll',schedule,{passive:true});

  function summary(out) {
    return {
      claims:out.claims.length,
      patternCount:out.patternHits.reduce((s,x)=>s+x.count,0),
      patterns:out.patternHits.map(x=>({id:x.id,name:x.name,count:x.count,group:x.group})).sort((a,b)=>b.count-a.count),
      sourceGaps:out.uncertainties.length,
      elementsMarked:state.markers.length+state.domBadges.length,
      measured:{characters:out.source.length,sentences:out.structure.sentences,candidates:state.candidates.length,preselected:document.querySelectorAll('input[type="checkbox"]:checked,input[type="radio"]:checked,select option:checked').length}
    };
  }
  function buildPanel(out) {
    state.panel?.remove();
    const root=document.createElement('section'); root.id='bhc-xray-intercept-root'; root.setAttribute('aria-label','BHC X-Ray Intercept');
    const sum=summary(out); const top=sum.patterns.slice(0,8);
    root.innerHTML=`<div class="bhcx-head"><div><p class="bhcx-kicker">BHC X-RAY INTERCEPT · ACTIVE TAB ONLY</p><h2>Riisutaanpa tämä.</h2></div><button type="button" data-action="close" aria-label="Sulje X-Ray">×</button></div><div class="bhcx-body"><div class="bhcx-metrics"><div class="bhcx-metric"><span>TEXT</span><strong>${sum.measured.characters.toLocaleString('fi-FI')}</strong></div><div class="bhcx-metric"><span>CLAIMS</span><strong>${sum.claims}</strong></div><div class="bhcx-metric"><span>PATTERNS</span><strong>${sum.patternCount}</strong></div><div class="bhcx-metric"><span>CHECKS</span><strong>${sum.sourceGaps}</strong></div><div class="bhcx-metric"><span>MARKERS</span><strong>${sum.elementsMarked}</strong></div><div class="bhcx-metric"><span>LENS</span><strong>${String(state.lens).toUpperCase()}</strong></div></div><div class="bhcx-section"><h3>PATTERN HITS · HEURISTIC</h3><div class="bhcx-list">${top.length?top.map(x=>`<div class="bhcx-row"><b>${escapeHtml(x.name)}</b><span>× ${x.count}</span></div>`).join(''):'<p class="bhcx-note">Ei osumia tämän sanaston mukaan.</p>'}</div></div><div class="bhcx-section"><h3>EPISTEMIC BRAKE</h3><p class="bhcx-note">Merkintä kertoo, että elementin teksti muistuttaa Pattern Libraryn rakennetta. Se ei todista sivun tekijän intentiota, väitteen vääryyttä tai esimerkiksi varastomäärän epäaitoutta.</p></div><div class="bhcx-actions"><button type="button" data-action="toggle">◐ Poista iho</button><button type="button" data-action="rescan">↻ Skannaa uudelleen</button></div></div>`;
    root.addEventListener('click',e=>{const a=e.target.closest('[data-action]')?.dataset.action;if(a==='close'){root.remove();state.panel=null;}if(a==='toggle')toggleOverlay();if(a==='rescan')scan(state.lens,true);});
    document.documentElement.append(root); state.panel=root;
  }
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function scan(lens='general',open=true) {
    state.lens=lens; const core=globalThis.BHCUniversalCore; if(!core) throw new Error('Universal Core missing');
    const text=collectPageText(); const out=core.analyze(text,lens); state.result=out; renderMarkers(); if(open) buildPanel(out); return summary(out);
  }
  function toggleOverlay() { state.visible=!state.visible; [...state.markers,...state.domBadges].forEach(x=>x.style.display=state.visible?'block':'none'); return state.visible; }

  function clearFriction() {
    if(state.friction?.timer) clearInterval(state.friction.timer);
    state.friction?.root?.remove();
    state.friction=null;
  }
  function showFriction(evaluation) {
    clearFriction();
    if(!evaluation?.matched) return false;
    const root=document.createElement('section'); root.id='bhc-friction-intercept-root'; root.setAttribute('aria-label','BHC Friction Lab');
    const delay=Math.max(0,Number(evaluation.delayMinutes)||0); const ends=Date.now()+delay*60000;
    const rules=(evaluation.rules||[]).map(r=>r.name).filter(Boolean);
    const prompts=(evaluation.prompts||[]).filter(Boolean);
    const requireConfirm=!!evaluation.actions?.requireConfirm;
    root.innerHTML=`<div class="bhcf-card"><div class="bhcf-head"><div><p>BHC FRICTION LAB · OPT-IN</p><h2>Päätös on edelleen sinun.</h2></div><button type="button" data-action="skip" aria-label="Ohita kitka">×</button></div><div class="bhcf-time" data-clock>00:00</div><div class="bhcf-tags">${rules.map(x=>`<span>${escapeHtml(x)}</span>`).join('')}</div><div class="bhcf-prompts">${prompts.length?prompts.map(x=>`<blockquote>${escapeHtml(x)}</blockquote>`).join(''):'<p>Pysähdys itsessään on tämän säännön kitka.</p>'}</div>${evaluation.actions?.showJournal?'<div class="bhcf-note">JOURNAL · PWA:n Journal-dataa ei kopioida extensionin storageen. Avaa se erikseen BHC Universal X-Raysta, jos haluat käyttää sitä päätöksen tukena.</div>':''}<label class="bhcf-reflect"><span>Mitä huomaat nyt?</span><textarea rows="3" placeholder="Tämä teksti jää vain tälle sivulle eikä tallennu."></textarea></label>${requireConfirm?'<label class="bhcf-confirm"><input type="checkbox" data-confirm><span>Olen pysähtynyt ja teen seuraavan päätöksen tietoisesti.</span></label>':''}<div class="bhcf-actions">${evaluation.actions?.offerCalm?'<button type="button" data-action="calm">∿ Rauhoita näkymä</button>':''}<button type="button" data-action="continue" disabled>Jatka sivulle</button><button type="button" data-action="skip">Ohita kitka</button></div><p class="bhcf-fine">Vapaaehtoinen kitka. Ei taustavalvontaa, ei automaattista estoa.</p></div>`;
    document.documentElement.append(root);
    const clock=root.querySelector('[data-clock]'), cont=root.querySelector('[data-action="continue"]'), confirm=root.querySelector('[data-confirm]');
    const update=()=>{const ms=Math.max(0,ends-Date.now()),total=Math.ceil(ms/1000),m=Math.floor(total/60),sec=total%60;clock.textContent=`${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;const ok=ms<=0&&(!requireConfirm||confirm?.checked);cont.disabled=!ok;if(ms<=0&&state.friction?.timer){clearInterval(state.friction.timer);state.friction.timer=null;}};
    root.addEventListener('change',e=>{if(e.target===confirm)update();});
    root.addEventListener('click',e=>{const action=e.target.closest('[data-action]')?.dataset.action;if(action==='skip'||action==='continue')clearFriction();if(action==='calm'){const card=root.querySelector('.bhcf-card');card.classList.toggle('bhcf-calm');e.target.textContent=card.classList.contains('bhcf-calm')?'∿ Rauha päällä':'∿ Rauhoita näkymä';}});
    state.friction={root,ends,timer:setInterval(update,250),evaluation}; update();
    return true;
  }
  function clearAll() { removeMarkers(); state.panel?.remove(); state.panel=null; state.result=null; clearFriction(); }

  const api=globalThis.browser||globalThis.chrome;
  api.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
    try {
      if(msg?.type==='BHC_XRAY_SCAN'){sendResponse({ok:true,summary:scan(msg.lens||'general',msg.open!==false)});return;}
      if(msg?.type==='BHC_XRAY_TOGGLE_OVERLAY'){sendResponse({ok:true,visible:toggleOverlay()});return;}
      if(msg?.type==='BHC_XRAY_CLEAR'){clearAll();sendResponse({ok:true});return;}
      if(msg?.type==='BHC_XRAY_GET_STATE'){sendResponse({ok:true,visible:state.visible,summary:state.result?summary(state.result):null,friction:!!state.friction});return;}
      if(msg?.type==='BHC_FRICTION_SHOW'){sendResponse({ok:true,shown:showFriction(msg.evaluation)});return;}
      if(msg?.type==='BHC_FRICTION_CLEAR'){clearFriction();sendResponse({ok:true});return;}
    } catch(err){sendResponse({ok:false,error:String(err?.message||err)});}
  });
})();
