(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const $ = q => document.querySelector(q);
  const result = $('#result');
  const setResult = html => { result.innerHTML = html; };
  const escapeHtml = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  async function currentTab() {
    const tabs = await api.tabs.query({ active:true, currentWindow:true });
    const tab = tabs?.[0];
    if (!tab?.id) throw new Error('Aktiivista välilehteä ei löytynyt.');
    return tab;
  }
  async function ensureInjected(tabId) {
    await api.scripting.insertCSS({ target:{ tabId }, files:['intercept.css'] });
    await api.scripting.executeScript({ target:{ tabId }, files:['shared/pattern-library.js','shared/friction-core.js','shared/universal-core.js','intercept-content.js'] });
  }
  async function send(tabId, message) { return api.tabs.sendMessage(tabId, message); }
  function restrictedMessage(err) {
    const msg=String(err?.message || err || 'Tuntematon virhe');
    setResult(`<p class="warn"><strong>Ei injektiota tälle sivulle.</strong><br>${escapeHtml(msg)}</p><p>Selain estää laajennusskriptit esimerkiksi omilla asetussivuillaan ja tietyillä suojatuilla sivuilla.</p>`);
  }
  function renderSummary(s) {
    if (!s) return setResult('<p>Ei tulosta.</p>');
    const top=(s.patterns||[]).slice(0,4).map(x=>`${escapeHtml(x.name)} × ${x.count}`).join('<br>') || 'Ei pattern-osumia.';
    setResult(`<p><strong>${s.claims} väitettä · ${s.patternCount} pattern-osumaa</strong></p><p>${top}</p><p>${s.sourceGaps} tarkistusaukkoa · ${s.elementsMarked} DOM-merkintää</p>`);
  }

  async function getFrictionRules() {
    const stored=await api.storage.local.get(['frictionRules']);
    return Array.isArray(stored?.frictionRules) ? stored.frictionRules : [];
  }
  async function updateFrictionCount() {
    const rules=await getFrictionRules();
    $('#frictionRuleCount').textContent=String(rules.filter(r=>r?.enabled!==false).length);
  }
  async function maybeRunFriction(tab, summary) {
    const rules=await getFrictionRules();
    if(!rules.length || !globalThis.BHCFrictionCore) return null;
    const evaluation=globalThis.BHCFrictionCore.evaluate({url:tab.url||'',patternIds:(summary?.patterns||[]).map(x=>x.id)},rules);
    if(evaluation.matched) await send(tab.id,{type:'BHC_FRICTION_SHOW',evaluation});
    return evaluation;
  }

  $('#scan').addEventListener('click', async () => {
    const lens=$('#lens').value;
    await api.storage.local.set({ lens });
    setResult('<p>R-02 avaa skalpellia…</p>');
    try {
      const tab=await currentTab(); await ensureInjected(tab.id);
      const res=await send(tab.id,{ type:'BHC_XRAY_SCAN', lens, open:true });
      if (!res?.ok) throw new Error(res?.error || 'Sivuanalyysi epäonnistui.');
      renderSummary(res.summary);
      const friction=await maybeRunFriction(tab,res.summary);
      if(friction?.matched) setResult(result.innerHTML+`<p><strong>Friction:</strong> ${friction.matchedCount} sääntöä · ${friction.delayMinutes} min.</p>`);
    } catch(err){ restrictedMessage(err); }
  });
  $('#toggle').addEventListener('click', async () => {
    try {
      const tab=await currentTab(); await ensureInjected(tab.id);
      const res=await send(tab.id,{ type:'BHC_XRAY_TOGGLE_OVERLAY' });
      if (!res?.ok) throw new Error(res?.error || 'Overlayn vaihto epäonnistui.');
      setResult(`<p><strong>Poista iho:</strong> ${res.visible ? 'merkinnät näkyvät' : 'merkinnät piilotettu'}</p>`);
    } catch(err){ restrictedMessage(err); }
  });
  $('#clear').addEventListener('click', async () => {
    try {
      const tab=await currentTab(); await ensureInjected(tab.id);
      const res=await send(tab.id,{ type:'BHC_XRAY_CLEAR' });
      if (!res?.ok) throw new Error(res?.error || 'Merkintöjen poisto epäonnistui.');
      setResult('<p>Merkinnät ja X-Ray-paneeli poistettu tältä sivulta.</p>');
    } catch(err){ restrictedMessage(err); }
  });
  $('#frictionImport').addEventListener('change', async e=>{
    const file=e.target.files?.[0]; if(!file) return;
    try{
      const payload=JSON.parse(await file.text());
      if(!globalThis.BHCFrictionCore) throw new Error('Friction Core missing');
      let rules;
      if(payload?.format==='bhc-universal-xray-vault') {
        const portable=payload?.extensionBridge?.frictionRules ?? payload?.data?.friction;
        if(!Array.isArray(portable)) throw new Error('System Vault ei sisällä siirrettäviä Friction Rules -sääntöjä.');
        rules=portable.map(globalThis.BHCFrictionCore.normalizeRule);
      } else {
        rules=globalThis.BHCFrictionCore.importBundle(payload);
      }
      await api.storage.local.set({frictionRules:rules});
      await updateFrictionCount();
      setResult(`<p><strong>${rules.length} Friction Rules -sääntöä tuotu.</strong></p><p>Ne tarkistetaan vasta X-Ray-skannauksen yhteydessä.</p>`);
    }catch(err){setResult(`<p class="warn"><strong>Tuonti epäonnistui.</strong><br>${escapeHtml(err.message||err)}</p>`);} e.target.value='';
  });
  $('#frictionClear').addEventListener('click', async()=>{await api.storage.local.remove('frictionRules');await updateFrictionCount();setResult('<p>Friction Rules tyhjennetty extensionista.</p>');});
  $('#atlas').addEventListener('click', () => api.tabs.create({ url:api.runtime.getURL('pattern-atlas.html') }));

  updateFrictionCount().catch(()=>{});
  api.storage.local.get(['lens']).then(x=>{
    if (x?.lens && [...$('#lens').options].some(o=>o.value===x.lens)) $('#lens').value=x.lens;
  }).catch(()=>{});
})();
